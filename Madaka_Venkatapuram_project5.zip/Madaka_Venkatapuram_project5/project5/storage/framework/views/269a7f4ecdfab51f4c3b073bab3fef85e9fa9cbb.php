<?php $__env->startComponent('mail::message'); ?>
    <strong>Name</strong> <?php echo e($userev['name']); ?>

    <strong>Email</strong> <?php echo e($userev['email']); ?>

    <strong>Subject</strong> New Account

    <strong>Message</strong>
   New <?php echo e($userev['role']); ?> Account created

    Thanks,<br>
    <?php echo e(config('app.name')); ?>

<?php if (isset($__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d)): ?>
<?php $component = $__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d; ?>
<?php unset($__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php /**PATH C:\xampp\htdocs\Laravel\project5\resources\views/email/registerform.blade.php ENDPATH**/ ?>