<?php $__env->startComponent('mail::message'); ?>
<strong>Name</strong> <?php echo e($data['name']); ?>

<strong>Email</strong> <?php echo e($data['email']); ?>

<strong>Subject</strong> <?php echo e($data['subject']); ?>


<strong>Message</strong>
<?php echo e($data['message']); ?>


Thanks,<br>
<?php echo e(config('app.name')); ?>

<?php if (isset($__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d)): ?>
<?php $component = $__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d; ?>
<?php unset($__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php /**PATH C:\xampp\htdocs\Laravel\project5\resources\views/email/form.blade.php ENDPATH**/ ?>